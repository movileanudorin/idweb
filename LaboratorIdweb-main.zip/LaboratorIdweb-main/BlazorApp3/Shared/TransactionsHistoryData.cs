﻿namespace BlazorApp3.Shared
{
    public class TransactionsHistoryData
    {
        public TransactionDto[] Transactions { get; set; }
        public int ItemCount { get; set; }
    }
}
