﻿namespace BlazorApp3.Shared
{
    public enum Direction
    {
        None,
        Inbound,
        Outbound
    }
}
