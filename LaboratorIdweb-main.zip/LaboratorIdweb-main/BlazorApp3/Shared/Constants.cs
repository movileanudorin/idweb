﻿namespace BlazorApp3.Shared
{
    public static class Constants
    {
        public static string transferSuccess = "transferSuccess";
    }
}
