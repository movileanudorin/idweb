﻿namespace BlazorApp3.Shared
{
    public class UserValidationResult
    {
        public bool Exists { get; set; }
    }
}
