﻿using System.Collections.Generic;

namespace BlazorApp3.Shared
{
    public class CurrencyList
    {
        public List<string> Currencies { get; set; }
    }
}
